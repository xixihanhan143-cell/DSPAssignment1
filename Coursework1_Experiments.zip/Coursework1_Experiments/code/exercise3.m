% Exercise 3. Identify the scale and its note order from the original audio.
runExercise3(fileparts(mfilename('fullpath')), ...
    exist('courseworkBatch', 'var') && isequal(courseworkBatch, true));

function runExercise3(codeDir, batchLogging)
root = fileparts(codeDir);
out = fullfile(root, 'figures', 'exercise3');
if ~batchLogging
    diary(fullfile(root, 'logs', 'execution.log'));
    logCleanup = onCleanup(@() diary('off')); %#ok<NASGU>
end
fprintf('\nExercise 3 | %s\n', version);
[x, Fs] = audioread(fullfile(root, 'data', 'yueyin1.wav'));
[N, channelCount] = size(x);
x = x(:, 1);
duration = N/Fs;
t = (0:N-1).' / Fs;
L = 2^nextpow2(4*N);
[f, A] = oneSided(x, Fs, L);
peakBins = find(A(2:end-1) > A(1:end-2) & A(2:end-1) >= A(3:end)) + 1;
peakBins = peakBins(f(peakBins) >= 70 & A(peakBins) >= 0.35 * max(A));
[globalHz, globalAmp] = refinePeaks(f, A, peakBins);
globalRows = makeRows("global_peak", nan(size(peakBins)), nan(size(peakBins)), ...
    nan(size(peakBins)), Fs, N, L, channelCount, f(peakBins), globalHz, globalAmp);

% Locate changes in the dominant pitch of overlapping Hann-windowed frames.
% Retain runs that persist over at least one frame duration. Short runs
% near a note change can show an intermediate pitch or an unstable peak.
frameN = round(0.032*Fs);
hop = round(0.005*Fs);
frameL = 2^nextpow2(16*frameN);
window = 0.5 - 0.5*cos(2*pi*(0:frameN-1).'/(frameN-1));
starts = (1:hop:N-frameN+1).';
frameLabels = zeros(size(starts));
for row = 1:numel(starts)
    frame = x(starts(row):starts(row)+frameN-1);
    [frameHz, frameAmp] = oneSided(frame .* window, Fs, frameL);
    band = find(frameHz >= 70 & frameHz <= 1500);
    [~, strongest] = max(frameAmp(band));
    frameLabels(row) = round(69 + 12*log2(frameHz(band(strongest))/440));
end
runEdges = [1; find(diff(frameLabels) ~= 0)+1; numel(frameLabels)+1];
runStarts = runEdges(1:end-1);
runStops = runEdges(2:end)-1;
stable = find(runStops-runStarts+1 >= ceil(frameN/hop));
pitches = frameLabels(runStarts(stable));
newNotes = find(diff(pitches) ~= 0);
centers = starts + (frameN-1)/2;
envelope = sqrt(movmean(x.^2, max(1, round(0.005*Fs))));
edges = [1; zeros(numel(newNotes), 1); N+1];
% Refine the stable pitch transition using the nearby local energy minimum.
for row = 1:numel(newNotes)
    preceding = runStops(stable(newNotes(row)));
    following = runStarts(stable(newNotes(row)+1));
    midpoint = round(mean(centers([preceding following])));
    halfFrame = floor(frameN/2);
    region = max(2, midpoint-halfFrame):min(N, midpoint+halfFrame);
    [~, low] = min(envelope(region));
    edges(row+1) = region(low);
end
assert(all(diff(edges) > 0), 'Detected note boundaries are out of order.');

noteCount = numel(edges) - 1;
segments = cell(noteCount, 1);
segmentRows = cell(noteCount, 1);
for row = 1:noteCount
    segment = x(edges(row):edges(row+1)-1);
    segmentL = 2^nextpow2(8*numel(segment));
    [segmentHz, segmentAmp] = oneSided(segment, Fs, segmentL);
    band = find(segmentHz >= 70);
    [~, strongest] = max(segmentAmp(band));
    peakBin = band(strongest);
    [measuredHz, measuredAmp] = refinePeaks(segmentHz, segmentAmp, peakBin);
    segmentRows{row} = makeRows("note_segment", row, (edges(row)-1)/Fs, ...
        (edges(row+1)-1)/Fs, Fs, numel(segment), segmentL, channelCount, ...
        segmentHz(peakBin), measuredHz, measuredAmp);
    segments{row} = struct('frequency', segmentHz, 'amplitude', segmentAmp);
end
notes = vertcat(segmentRows{:});
writetable([globalRows; notes], fullfile(root, 'results', 'exercise3_results.csv'));
fprintf('yueyin1.wav | Fs=%d Hz | N=%d | channels=%d | T=%.6f s | L=%d\n', ...
    Fs, N, channelCount, duration, L);
for row = 1:height(notes)
    fprintf('%d: %.6f-%.6f s | %s | %.6f Hz\n', row, notes.Start_s(row), ...
        notes.End_s(row), char(notes.Note(row)), notes.Measured_Hz(row));
end

blue = [0.12 0.30 0.49];
rust = [0.64 0.24 0.16];
fig = newFigure([1120 430]);
ax = axes(fig);
plot(ax, t, x, 'Color', blue, 'LineWidth', 0.65);
hold(ax, 'on');
xline(ax, notes.Start_s(2:end), '--', 'Color', [0.40 0.40 0.40]);
for row = 1:noteCount
    text(ax, mean([notes.Start_s(row), notes.End_s(row)]), 1.05, ...
        notes.Note(row), 'HorizontalAlignment', 'center', 'FontName', ...
        'Times New Roman', 'FontSize', 11, 'Color', rust);
end
xlim(ax, [0 duration]);
ylim(ax, [-1.02 1.15]);
xlabel(ax, 'Time (s)');
ylabel(ax, 'Amplitude');
title(ax, 'Scale recording and detected note boundaries');
styleAxes(ax);
savePlot(fig, out, '01_scale_waveform');

fig = newFigure([970 410]);
ax = axes(fig);
plot(ax, f, A, 'Color', blue, 'LineWidth', 1);
xlim(ax, [0 Fs/2]);
ylim(ax, [0 1.12*max(A)]);
xlabel(ax, 'Frequency (Hz)');
ylabel(ax, 'Single-sided amplitude');
title(ax, 'Full-record magnitude spectrum');
styleAxes(ax);
savePlot(fig, out, '02_scale_full_spectrum');

fig = newFigure([1120 450]);
ax = axes(fig);
plot(ax, f, A, 'Color', blue, 'LineWidth', 1.05);
hold(ax, 'on');
plot(ax, globalHz, globalAmp, 'o', 'MarkerSize', 5, ...
    'Color', rust, 'MarkerFaceColor', 'w', 'LineWidth', 1);
for row = 1:height(globalRows)
    level = 1.14 + 0.14*mod(row,2);
    label = sprintf('%s\n%.2f Hz', char(globalRows.Note(row)), globalHz(row));
    plot(ax, [globalHz(row) globalHz(row)], ...
        [globalAmp(row) level*max(A)-0.002], ':', 'Color', rust);
    text(ax, globalHz(row), level*max(A), label, 'VerticalAlignment', ...
        'bottom', 'HorizontalAlignment', 'center', 'FontName', ...
        'Times New Roman', 'FontSize', 10, 'Color', rust);
end
viewRange = [max(0, min(globalHz)-28), max(globalHz)+28];
xlim(ax, viewRange);
ylim(ax, [0 1.53*max(A)]);
xlabel(ax, 'Frequency (Hz)');
ylabel(ax, 'Single-sided amplitude');
title(ax, 'Principal peaks in the full-record spectrum');
styleAxes(ax);
savePlot(fig, out, '03_scale_annotated_peaks');

fig = newFigure([1090 680]);
tiles = tiledlayout(fig, ceil(noteCount/2), 2, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tiles, 'Individual note spectra in time order', 'FontName', 'Times New Roman');
for row = 1:noteCount
    ax = nexttile(tiles);
    s = segments{row};
    trace = plot(ax, s.frequency, s.amplitude, 'Color', blue, 'LineWidth', 1.05);
    hold(ax, 'on');
    reference = xline(ax, notes.Standard_Hz(row), '--', 'Color', [0.4 0.4 0.4]);
    marker = plot(ax, notes.Measured_Hz(row), notes.PeakAmplitude(row), 'o', ...
        'Color', rust, 'MarkerFaceColor', 'w', 'MarkerSize', 4);
    xlim(ax, viewRange);
    ylim(ax, [0 1.12*max(notes.PeakAmplitude)]);
    title(ax, sprintf('%d. %s | %.2f Hz | %.3f-%.3f s', row, ...
        char(notes.Note(row)), notes.Measured_Hz(row), notes.Start_s(row), notes.End_s(row)));
    styleAxes(ax);
    if row == 1
        key = legend(ax, [trace, reference, marker], ...
            {'Segment spectrum', 'Standard pitch', 'Measured peak'}, ...
            'FontName', 'Times New Roman', 'Orientation', 'horizontal', 'Box', 'off');
        key.Layout.Tile = 'south';
    end
end
xlabel(tiles, 'Frequency (Hz)', 'FontName', 'Times New Roman');
ylabel(tiles, 'Single-sided amplitude', 'FontName', 'Times New Roman');
savePlot(fig, out, '04_scale_segment_spectra');
fprintf('Exercise 3 complete. 4 figures and exercise3_results.csv saved.\n');
end

function result = makeRows(kind, noteIndex, tStart, tEnd, Fs, N, L, channels, binHz, measuredHz, amplitude)
midi = round(69 + 12*log2(measuredHz/440));
names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"].';
names = names(mod(midi,12)+1) + string(floor(midi/12)-1);
standard = 440 * 2.^((midi-69)/12);
m = numel(measuredHz);
result = table(repmat(kind,m,1), (1:m).', noteIndex, tStart, tEnd, ...
    repmat(Fs,m,1), repmat(N,m,1), repmat(channels,m,1), repmat(N/Fs,m,1), ...
    repmat(L,m,1), repmat(Fs/L,m,1), binHz, measuredHz, names, standard, ...
    measuredHz-standard, amplitude, 'VariableNames', {'Group', 'Peak', 'NoteIndex', ...
    'Start_s', 'End_s', 'Fs_Hz', 'N', 'Channels', 'Duration_s', 'L', 'Grid_Hz', ...
    'Bin_Hz', 'Measured_Hz', 'Note', 'Standard_Hz', 'Error_Hz', 'PeakAmplitude'});
end

function [f, A] = oneSided(x, Fs, L)
A = abs(fft(x,L)) / numel(x);
A = A(1:floor(L/2)+1);
A(2:end-1) = 2*A(2:end-1); % FFT lengths used here are even.
f = (0:floor(L/2)).' * (Fs/L);
end

function [hz, amplitude] = refinePeaks(f, A, i)
left = log(A(i-1));
middle = log(A(i));
right = log(A(i+1));
offset = 0.5*(left-right)./(left-2*middle+right);
hz = f(i) + offset*(f(2)-f(1));
amplitude = exp(middle - 0.25*(left-right).*offset);
end

function fig = newFigure(dimensions)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 dimensions]);
end

function styleAxes(ax)
set(ax, 'FontName', 'Times New Roman', 'FontSize', 11, 'Box', 'on', ...
    'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.13);
end

function savePlot(fig, folder, name)
base = fullfile(folder, name);
exportgraphics(fig, [base '.png'], 'Resolution', 320);
exportgraphics(fig, [base '.pdf'], 'ContentType', 'vector');
savefig(fig, [base '.fig']);
close(fig);
end
