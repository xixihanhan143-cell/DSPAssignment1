% Run all three experiments in sequence and capture the MATLAB transcript.
runCoursework(fileparts(mfilename('fullpath')));

function runCoursework(codeDir)
logfile = fullfile(fileparts(codeDir), 'logs', 'execution.log');
fid = fopen(logfile, 'w');
assert(fid ~= -1, 'Could not open the execution log for writing.');
fclose(fid);
diary(logfile);
finishLog = onCleanup(@() diary('off')); %#ok<NASGU>
timestamp = @() char(datetime('now', 'TimeZone', 'Asia/Shanghai', ...
    'Format', 'yyyy-MM-dd HH:mm:ss z'));
fprintf('Coursework 1 | MATLAB %s | %s\n', version, computer);
fprintf('Started %s\n', timestamp());
courseworkBatch = true; %#ok<NASGU> % Child scripts share this function workspace.
try
    run(fullfile(codeDir, 'exercise2.m'));
    run(fullfile(codeDir, 'exercise3.m'));
    run(fullfile(codeDir, 'exercise4.m'));
    fprintf('\nAll three experiments completed | %s\n', timestamp());
catch problem
    fprintf(2, '\nExecution failed | %s\n%s\n', timestamp(), ...
        getReport(problem, 'extended', 'hyperlinks', 'off'));
    rethrow(problem);
end
end
