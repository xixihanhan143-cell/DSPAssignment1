# Coursework 1 · DFT 频谱实验

本目录包含 Exercise 2、3、4 的 MATLAB 程序、原始音频、实验数据、图和中文分析。课程任务书为《Approximate Calculation of Signal Spectrum with DFT》。两份 WAV 从课程归档提取，并与工作区原有文件逐字节核对。

## 运行

在 MATLAB 中把当前文件夹切换到本目录的 `code/`，输入 `run_all`。也可从其他目录通过 `run` 指定 `code/run_all.m` 的完整路径。可单独运行 `exercise2`、`exercise3`、`exercise4`。脚本使用自身位置定位 `data/` 和输出，主要计算使用基础 MATLAB 函数。

```matlab
run('code/run_all.m')
```

以上相对路径示例从 `Coursework1_Experiments/` 目录运行。在可正常启动 MATLAB 命令行的系统上，也可从 `code/` 执行 `matlab -batch "run_all"`。

本次结果由 macOS Apple Silicon 上的 **MATLAB R2026b（26.2.0.3386108）** 桌面命令窗口实际运行生成。终端批处理启动时出现 Qt NEON 检测错误，因此改用 MATLAB 桌面。运行 `run_all` 会刷新 `logs/execution.log`，单独运行一个实验会追加该实验的运行输出。重新运行脚本会更新相应的图和 CSV。

## 文件

| 实验 | 分析与数据 | 图数 |
| --- | --- | ---: |
| 2 · 近频分离 | [分析](results/exercise2_analysis.md) · [CSV](results/exercise2_results.csv) | 2 |
| 3 · 音阶识别 | [分析](results/exercise3_analysis.md) · [CSV](results/exercise3_results.csv) | 4 |
| 4 · 和弦与短时频谱 | [分析](results/exercise4_analysis.md) · [CSV](results/exercise4_results.csv) | 4 |

每张图位于相应的 `figures/exerciseN/`，共有 320 DPI PNG、矢量 PDF、可编辑 MATLAB FIG 三种格式。CSV 中的 FFT 网格坐标与插值估计使用不同列。空值或 `NaN` 对应当前分组没有定义的字段。音频频率误差使用实测值减 A4 = 440 Hz 的十二平均律标准值。短时和弦额外列出峰位相对于合成输入频率的偏差。
