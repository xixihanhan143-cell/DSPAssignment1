% Exercise 4. Identify a recorded chord and measure the effect of time truncation.
runExercise4(fileparts(mfilename('fullpath')), ...
    exist('courseworkBatch', 'var') && isequal(courseworkBatch, true));

function runExercise4(codeDir, batchLogging)
root = fileparts(codeDir);
out = fullfile(root, 'figures', 'exercise4');
if ~batchLogging
    diary(fullfile(root, 'logs', 'execution.log'));
    logCleanup = onCleanup(@() diary('off')); %#ok<NASGU>
end
fprintf('\nExercise 4 | %s\n', version);
[x, Fs] = audioread(fullfile(root, 'data', 'hexian1.wav'));
[N, channelCount] = size(x);
x = x(:,1);
L = 2^nextpow2(8*N);
[f, A] = oneSided(x, Fs, L);
bins = find(A(2:end-1) > A(1:end-2) & A(2:end-1) >= A(3:end)) + 1;
bins = bins(f(bins) >= 70 & A(bins) >= 0.35*max(A));
assert(numel(bins) == 3, 'Expected three principal peaks in the recorded triad.');

% Interpolate the logarithmic magnitude around each recorded peak.
left = log(A(bins-1));
middle = log(A(bins));
right = log(A(bins+1));
offset = 0.5*(left-right)./(left-2*middle+right);
frequencies = f(bins) + offset*(Fs/L);
amplitudes = exp(middle - 0.25*(left-right).*offset);
midi = round(69 + 12*log2(frequencies/440));
names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"].';
notes = names(mod(midi,12)+1) + string(floor(midi/12)-1);
standard = 440 * 2.^((midi-69)/12);
chord = identifyTriad(midi, names);
m = numel(frequencies);
original = table(repmat("original_chord",m,1), repmat(Fs,m,1), repmat(channelCount,m,1), ...
    repmat(N,m,1), repmat(N/Fs,m,1), repmat(L,m,1), repmat(Fs/L,m,1), ...
    repmat(Fs/N,m,1), (1:m).', f(bins), frequencies, amplitudes, notes, standard, ...
    frequencies-standard, nan(m,1), nan(m,1), nan(m,1), nan(m,1), ...
    repmat(chord,m,1), 'VariableNames', {'Group', 'Fs_Hz', 'Channels', 'N', ...
    'Duration_s', 'L', 'Grid_Hz', 'RectNullOffset_Hz', 'Peak', 'Bin_Hz', ...
    'Measured_Hz', 'PeakAmplitude', 'Note', 'Standard_Hz', 'Error_Hz', ...
    'NearestSource_Hz', 'ErrorToSource_Hz', 'MatchedTonesWithin5Hz', ...
    'MaxValleyToWeakerPeak', 'Chord'});

fprintf('hexian1.wav | Fs=%d Hz | N=%d | channels=%d | T=%.6f s | L=%d\n', ...
    Fs, N, channelCount, N/Fs, L);
fprintf('%s | frequencies (Hz):%s\n', char(chord), sprintf(' %.6f', frequencies));
durations = [1 0.2 0.1 0.05 0.2/16];
counts = round(durations*Fs);
commonL = 2^nextpow2(8*max(counts));
padding = [counts(end) 512 1024 4096];
searchBand = [min(frequencies)-50, max(frequencies)+50];
allResults = original;
durationSpectra = cell(size(counts));
for row = 1:numel(counts)
    time = (0:counts(row)-1).' / Fs;
    synthetic = sum(cos(2*pi*time*frequencies.'), 2);
    [durationSpectra{row}, rows] = evaluateSpectrum(synthetic, Fs, commonL, ...
        "duration_group_" + string(row), frequencies, searchBand, original.Properties.VariableNames);
    allResults = [allResults; rows]; %#ok<AGROW>
end

paddingSpectra = cell(size(padding));
% synthetic still holds the shortest group, with identical samples at every L.
for row = 1:numel(padding)
    [paddingSpectra{row}, rows] = evaluateSpectrum(synthetic, Fs, padding(row), ...
        "short_zero_padding", frequencies, searchBand, original.Properties.VariableNames);
    allResults = [allResults; rows]; %#ok<AGROW>
end
[~, excerptRows] = evaluateSpectrum(x(1:counts(end)), Fs, padding(end), ...
    "original_first_100", frequencies, searchBand, original.Properties.VariableNames);
allResults = [allResults; excerptRows];
writetable(allResults, fullfile(root, 'results', 'exercise4_results.csv'));

blue = [0.12 0.30 0.49];
rust = [0.64 0.24 0.16];
fig = newFigure([1040 445]);
tiles = tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');
title(tiles, 'Chord recording', 'FontName', 'Times New Roman');
ax = nexttile(tiles);
time = (0:N-1).' / Fs;
plot(ax, time, x, 'Color', blue, 'LineWidth', 0.65);
xlim(ax, [0 N/Fs]);
ylim(ax, [-1.05 1.05]);
xlabel(ax, 'Time (s)');
ylabel(ax, 'Amplitude');
title(ax, 'Complete recording');
styleAxes(ax);
ax = nexttile(tiles);
plot(ax, time, x, 'Color', blue, 'LineWidth', 1);
xlim(ax, [0 0.05]);
ylim(ax, [-1.05 1.05]);
xlabel(ax, 'Time (s)');
ylabel(ax, 'Amplitude');
title(ax, 'First 50 ms');
styleAxes(ax);
savePlot(fig, out, '01_chord_waveform');

fig = newFigure([1080 445]);
tiles = tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');
title(tiles, 'Recorded chord spectrum', 'FontName', 'Times New Roman');
ax = nexttile(tiles);
plot(ax, f, A, 'Color', blue, 'LineWidth', 1);
xlim(ax, [0 Fs/2]);
ylim(ax, [0 1.31*max(A)]);
title(ax, 'Full one-sided spectrum');
styleAxes(ax);
ax = nexttile(tiles);
trace = plot(ax, f, A, 'Color', blue, 'LineWidth', 1);
hold(ax, 'on');
reference = xline(ax, standard, '--', 'Color', [0.4 0.4 0.4]);
marker = plot(ax, frequencies, amplitudes, 'o', 'Color', rust, 'MarkerFaceColor', 'w', 'MarkerSize', 5);
for row = 1:m
    text(ax, frequencies(row), 1.08*max(A), ...
        sprintf('%s\n%.2f Hz', char(notes(row)), frequencies(row)), ...
        'HorizontalAlignment','center','FontName','Times New Roman','Color',rust);
end
xlim(ax, searchBand);
ylim(ax, [0 1.31*max(A)]);
title(ax, char(chord));
styleAxes(ax);
addSpectrumLegend(ax, [trace, reference(1), marker], 'Recorded spectrum', 'Standard pitches');
xlabel(tiles, 'Frequency (Hz)', 'FontName', 'Times New Roman');
ylabel(tiles, 'Single-sided amplitude', 'FontName', 'Times New Roman');
savePlot(fig, out, '02_chord_spectrum');

zoom = [floor((searchBand(1)-10)/20)*20, ceil((searchBand(2)+10)/20)*20];
fig = newFigure([1140 730]);
tiles = tiledlayout(fig,3,2,'TileSpacing','compact','Padding','compact');
title(tiles, sprintf('Synthetic chord: changing the observation length (L = %d)', ...
    commonL),'FontName','Times New Roman');
for row = 1:numel(counts)
    ax = nexttile(tiles);
    handles = drawComparison(ax, durationSpectra{row}, frequencies, zoom, false);
    if row == 1
        addSpectrumLegend(ax, handles, 'Synthetic spectrum', 'Input frequencies');
    end
    title(ax, sprintf('Group %d: T = %g s, N = %d', row, durations(row), counts(row)));
end
xlabel(tiles, 'Frequency (Hz)', 'FontName', 'Times New Roman');
ylabel(tiles, 'Single-sided amplitude', 'FontName', 'Times New Roman');
savePlot(fig, out, '03_chord_duration_comparison');

fig = newFigure([1120 635]);
tiles = tiledlayout(fig,2,2,'TileSpacing','compact','Padding','compact');
title(tiles, sprintf('Zero padding the same %d-sample chord', counts(end)), ...
    'FontName','Times New Roman');
for row = 1:numel(padding)
    ax = nexttile(tiles);
    handles = drawComparison(ax, paddingSpectra{row}, frequencies, zoom, true);
    if row == 1
        addSpectrumLegend(ax, handles, 'DFT samples', 'Input frequencies');
    end
    title(ax, sprintf('L = %d, grid = %.3f Hz', padding(row), Fs/padding(row)));
end
xlabel(tiles, 'Frequency (Hz)', 'FontName', 'Times New Roman');
ylabel(tiles, 'Single-sided amplitude', 'FontName', 'Times New Roman');
savePlot(fig, out, '04_short_chord_zero_padding');
fprintf('Exercise 4 complete. 4 figures and exercise4_results.csv saved.\n');
end

function chord = identifyTriad(midi, names)
chord = "Unclassified triad";
pitches = unique(mod(midi,12));
for root = pitches.'
    intervals = sort(mod(pitches-root,12)).';
    if isequal(intervals, [0 4 7])
        chord = names(root+1) + " major";
        return
    elseif isequal(intervals, [0 3 7])
        chord = names(root+1) + " minor";
        return
    end
end
end

function [s, rows] = evaluateSpectrum(x, Fs, L, group, frequencies, band, columns)
N = numel(x);
[f, A] = oneSided(x, Fs, L);
i = find(A(2:end-1) > A(1:end-2) & A(2:end-1) >= A(3:end)) + 1;
i = i(f(i) >= band(1) & f(i) <= band(2) & A(i) >= 0.35*max(A));
assert(~isempty(i), 'No principal peak found in the chord band.');
s = struct('frequency', f, 'amplitude', A, 'peaks', i);
[~, nearest] = min(abs(f(i)-frequencies.'), [], 2);
matched = nnz(min(abs(f(i)-frequencies.'),[],1) <= 5);
valleys = nan(numel(i)-1,1);
for j = 1:numel(valleys)
    valleys(j) = min(A(i(j):i(j+1))) / min(A(i(j)), A(i(j+1)));
end
valleyRatio = NaN;
if ~isempty(valleys)
    valleyRatio = max(valleys);
end
m = numel(i);
rows = table(repmat(group,m,1), repmat(Fs,m,1), ones(m,1), repmat(N,m,1), ...
    repmat(N/Fs,m,1), repmat(L,m,1), repmat(Fs/L,m,1), repmat(Fs/N,m,1), ...
    (1:m).', f(i), f(i), A(i), strings(m,1), nan(m,1), nan(m,1), ...
    frequencies(nearest), f(i)-frequencies(nearest), repmat(matched,m,1), ...
    repmat(valleyRatio,m,1), strings(m,1), 'VariableNames', columns);
fprintf('%-22s N=%-5d L=%-7d peaks (Hz):%s | matched %d/3 within 5 Hz\n', ...
    char(group), N, L, sprintf(' %.5f', f(i)), matched);
end

function [f, A] = oneSided(x, Fs, L)
A = abs(fft(x,L)) / numel(x);
A = A(1:floor(L/2)+1);
A(2:end-1) = 2*A(2:end-1); % FFT lengths used here are even.
f = (0:floor(L/2)).' * (Fs/L);
end

function handles = drawComparison(ax, s, reference, limits, showSamples)
blue = [0.12 0.30 0.49];
rust = [0.64 0.24 0.16];
hold(ax, 'on');
inView = s.frequency >= limits(1) & s.frequency <= limits(2);
if showSamples
    trace = stem(ax, s.frequency(inView), s.amplitude(inView), 'Color', blue, ...
        'Marker', '.', 'MarkerSize', 7, 'LineWidth', 0.7);
else
    trace = plot(ax, s.frequency(inView), s.amplitude(inView), 'Color', blue, 'LineWidth', 1.1);
end
referenceLines = xline(ax, reference, '--', 'Color', [0.40 0.40 0.40], 'LineWidth', 0.8);
marker = plot(ax, s.frequency(s.peaks), s.amplitude(s.peaks), 'o', 'Color', rust, ...
    'MarkerFaceColor', 'w', 'MarkerSize', 4.5);
xlim(ax, limits);
ylim(ax, [0 1.22]);
styleAxes(ax);
handles = [trace, referenceLines(1), marker];
end

function addSpectrumLegend(ax, handles, spectrumLabel, referenceLabel)
key = legend(ax, handles, {spectrumLabel, referenceLabel, 'Detected peaks'}, ...
    'FontName', 'Times New Roman', 'Orientation', 'horizontal', 'Box', 'off');
key.Layout.Tile = 'south';
end

function fig = newFigure(dimensions)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 dimensions]);
end

function styleAxes(ax)
set(ax, 'FontName', 'Times New Roman', 'FontSize', 11, 'Box', 'on', ...
    'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.13);
end

function savePlot(fig, folder, name)
base = fullfile(folder, name);
exportgraphics(fig, [base '.png'], 'Resolution', 320);
exportgraphics(fig, [base '.pdf'], 'ContentType', 'vector');
savefig(fig, [base '.fig']);
close(fig);
end
