% Exercise 2. Compare FFT grid spacing with the effects of record length.
runExercise2(fileparts(mfilename('fullpath')), ...
    exist('courseworkBatch', 'var') && isequal(courseworkBatch, true));

function runExercise2(codeDir, batchLogging)
root = fileparts(codeDir);
out = fullfile(root, 'figures', 'exercise2');
if ~batchLogging
    diary(fullfile(root, 'logs', 'execution.log'));
    logCleanup = onCleanup(@() diary('off')); %#ok<NASGU>
end
fprintf('\nExercise 2 | %s\n', version);
target = [12 13] / 64;
searchBand = [0.175 0.215];
configurations = [64 64; 64 128; 64 512; 128 128; 256 256; 512 512; ...
    128 4096; 256 4096; 512 4096];
groups = [repmat("fixed_data", 3, 1); repmat("native_grid", 3, 1); ...
    repmat("dense_grid", 3, 1)];
spectra = cell(size(configurations, 1), 1);
results = cell(size(spectra));

for row = 1:numel(spectra)
    N = configurations(row, 1);
    L = configurations(row, 2);
    k = (0:N-1).';
    x = cos(pi * target(1) * k) + 0.6 * cos(pi * target(2) * k);
    % fft(x,L) appends zeros when L > N. Retain N in the scaling.
    A = abs(fft(x, L)) / N;
    A = A(1:L/2+1);
    A(2:end-1) = 2 * A(2:end-1);
    f = (0:L/2).' * (2/L);
    allPeaks = find(A(2:end-1) > A(1:end-2) & A(2:end-1) >= A(3:end)) + 1;
    peaks = allPeaks(f(allPeaks) >= searchBand(1) & f(allPeaks) <= searchBand(2));
    % Report every local maximum in the band. Use a common amplitude floor
    % to distinguish the two strong peaks from rectangular-window sidelobes.
    main = A(peaks) >= 0.35;
    mainCount = nnz(main);
    valley = NaN;
    ratio = NaN;
    reference = NaN(size(peaks));
    errorFromReference = NaN(size(peaks));
    if mainCount == 2
        strong = peaks(main);
        valley = min(A(strong(1):strong(2)));
        ratio = valley / min(A(strong));
        reference(main) = target(:);
        errorFromReference(main) = f(strong) - target(:);
    end
    m = numel(peaks);
    spectra{row} = struct('N', N, 'L', L, 'frequency', f, 'amplitude', A, ...
        'peaks', peaks, 'main', main);
    results{row} = table(repmat(groups(row), m, 1), repmat(N, m, 1), ...
        repmat(L, m, 1), repmat(2*pi/L, m, 1), repmat(2/L, m, 1), ...
        repmat(2/N, m, 1), (1:m).', f(peaks), A(peaks), main, ...
        repmat(mainCount, m, 1), repmat(valley, m, 1), repmat(ratio, m, 1), ...
        reference, errorFromReference, 'VariableNames', {'Group', 'N', 'L', ...
        'Grid_rad_per_sample', 'Grid_Omega_over_pi', 'RectNullOffset_Omega_over_pi', ...
        'Peak', 'Peak_Omega_over_pi', 'Amplitude', 'IsMainPeak', 'MainPeakCount', ...
        'ValleyAmplitude', 'ValleyToWeakerPeak', 'Theory_Omega_over_pi', ...
        'Error_Omega_over_pi'});
    fprintf('N=%-4d L=%-4d main peak positions (Omega/pi):%s\n', ...
        N, L, sprintf(' %.8f', f(peaks(main))));
end

writetable(vertcat(results{:}), fullfile(root, 'results', 'exercise2_results.csv'));
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1040 770]);
tiles = tiledlayout(fig, 3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tiles, 'Fixed record length: N = 64', 'FontName', 'Times New Roman');
for row = 1:3
    ax = nexttile(tiles);
    handles = drawSpectrum(ax, spectra{row}, target, [0 1]);
    if row == 1
        addSpectrumLegend(ax, handles, 'DFT samples');
    end
    drawSpectrum(nexttile(tiles), spectra{row}, target, [0.14 0.25]);
end
xlabel(tiles, 'Normalized angular frequency, \Omega/\pi', ...
    'FontName', 'Times New Roman', 'Interpreter', 'tex');
ylabel(tiles, 'Single-sided amplitude', 'FontName', 'Times New Roman');
savePlot(fig, out, '01_fixed_length_zero_padding');

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1040 770]);
tiles = tiledlayout(fig, 3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tiles, 'Increasing the observation length', 'FontName', 'Times New Roman');
for row = 1:3
    drawSpectrum(nexttile(tiles), spectra{row+3}, target, [0.16 0.23]);
    ax = nexttile(tiles);
    handles = drawSpectrum(ax, spectra{row+6}, target, [0.16 0.23]);
    if row == 1
        addSpectrumLegend(ax, handles, 'Dense DFT grid');
    end
end
xlabel(tiles, 'Normalized angular frequency, \Omega/\pi', ...
    'FontName', 'Times New Roman', 'Interpreter', 'tex');
ylabel(tiles, 'Single-sided amplitude', 'FontName', 'Times New Roman');
savePlot(fig, out, '02_observation_length_comparison');
fprintf('Exercise 2 complete. 2 figures and exercise2_results.csv saved.\n');
end

function handles = drawSpectrum(ax, s, target, limits)
color = [0.12 0.30 0.49];
hold(ax, 'on');
outOfBand = s.frequency < limits(1) | s.frequency > limits(2);
if s.L == s.N || s.N == 64
    trace = stem(ax, s.frequency(~outOfBand), s.amplitude(~outOfBand), ...
        'Color', color, 'Marker', '.', 'MarkerSize', 8, 'LineWidth', 0.75);
else
    trace = plot(ax, s.frequency, s.amplitude, 'Color', color, 'LineWidth', 1.15);
end
reference = xline(ax, target, '--', 'Color', [0.40 0.40 0.40], 'LineWidth', 0.8);
peak = s.peaks(s.main);
marker = plot(ax, s.frequency(peak), s.amplitude(peak), 'o', 'MarkerSize', 5, ...
    'MarkerEdgeColor', [0.64 0.24 0.16], 'MarkerFaceColor', 'w', 'LineWidth', 1);
set(ax, 'FontName', 'Times New Roman', 'FontSize', 11, 'Box', 'on', ...
    'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.13);
xlim(ax, limits);
ylim(ax, [0 1.22]);
title(ax, sprintf('N = %d, L = %d', s.N, s.L));
handles = [trace, reference(1), marker];
end

function addSpectrumLegend(ax, handles, spectrumLabel)
key = legend(ax, handles, {spectrumLabel, 'Theoretical frequencies', 'Detected main peaks'}, ...
    'FontName', 'Times New Roman', 'Orientation', 'horizontal', 'Box', 'off');
key.Layout.Tile = 'south';
end

function savePlot(fig, folder, name)
base = fullfile(folder, name);
exportgraphics(fig, [base '.png'], 'Resolution', 320);
exportgraphics(fig, [base '.pdf'], 'ContentType', 'vector');
savefig(fig, [base '.fig']);
close(fig);
end
